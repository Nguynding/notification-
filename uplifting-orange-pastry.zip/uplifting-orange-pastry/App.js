import React from 'react';
import { Text, View, StyleSheet, SafeAreaView, Image } from 'react-native';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Thông báo</Text>
      
      <View style={[styles.notification, styles.notificationHighlight]}>
        <Image source={{ uri: 'https://png.pngtree.com/png-vector/20220730/ourlarge/pngtree-checkbox-icon-okay-valid-done-vector-png-image_19332640.jpg' }} style={styles.notificationImage} />
        <View style={styles.notificationContent}>
          <Text style={styles.notificationTitle}>Bước 1 Xác định nhu cầu khách hàng</Text>
          <Text style={styles.notificationText}>Vũ Văn Hoàng sắp đến hạn lúc 01/08/2020 9:00</Text>
          <Text style={styles.notificationDate}>20/08/2020, 06:00</Text>
        </View>
      </View>

      <View style={[styles.notification, styles.notificationHighlight]}>
        <Image source={{ uri: 'https://previews.123rf.com/images/vitechek/vitechek1907/vitechek190700199/126786791-user-login-or-authenticate-icon-human-person-symbol-vector.jpg' }} style={styles.notificationImage} />
        <View style={styles.notificationContent}>
          <Text style={styles.notificationTitle}>Bạn có khách hàng mới!</Text>
          <Text style={styles.notificationText}>Chúc mừng bạn, bạn có khách hàng mới. Hãy mau chóng liên lạc ngay.</Text>
          <Text style={styles.notificationDate}>20/08/2020, 06:00</Text>
        </View>
      </View>

      <View style={styles.notification}>
        <Image source={{ uri: 'https://previews.123rf.com/images/vitechek/vitechek1907/vitechek190700199/126786791-user-login-or-authenticate-icon-human-person-symbol-vector.jpg' }} style={styles.notificationImage} />
        <View style={styles.notificationContent}>
          <Text style={styles.notificationTitle}>Khách hàng được chia sẻ bị trùng!</Text>
          <Text style={styles.notificationText}>Rất tiếc, khách hàng được chia sẻ đã tồn tại trên hệ thống. Vui lòng chia sẻ khách hàng.</Text>
          <Text style={styles.notificationDate}>20/08/2020, 06:00</Text>
        </View>
      </View>

      <View style={[styles.notification, styles.notificationHighlight]}>
        <Image source={{ uri: 'https://png.pngtree.com/png-vector/20220730/ourlarge/pngtree-checkbox-icon-okay-valid-done-vector-png-image_19332640.jpg' }} style={styles.notificationImage} />
        <View style={styles.notificationContent}>
          <Text style={styles.notificationTitle}>Khách hàng được thêm bị trùng!</Text>
          <Text style={styles.notificationText}>Rất tiếc, khách hàng được chia sẻ đã tồn tại trên hệ thống. Vui lòng thêm khách hàng.</Text>
          <Text style={styles.notificationDate}>20/08/2020, 06:00</Text>
        </View>
      </View>

      <View style={styles.notification}>
      <Image source={{ uri: 'https://png.pngtree.com/png-vector/20220730/ourlarge/pngtree-checkbox-icon-okay-valid-done-vector-png-image_19332640.jpg' }} style={styles.notificationImage} />
        <View style={styles.notificationContent}>
          <Text style={styles.notificationTitle}>Công việc sắp đến hạn trong hôm nay</Text>
          <Text style={styles.notificationText}>Bạn có 17 công việc sắp đến hạn trong hôm nay.</Text>
          <Text style={styles.notificationDate}>20/08/2020, 06:00</Text>
        </View>
      </View>

      <View style={styles.notification}>
        <Image source={{ uri: 'https://previews.123rf.com/images/vitechek/vitechek1907/vitechek190700199/126786791-user-login-or-authenticate-icon-human-person-symbol-vector.jpg' }} style={styles.notificationImage} />
        <View style={styles.notificationContent}>
          <Text style={styles.notificationTitle}>Công việc đã quá hạn </Text>
          <Text style={styles.notificationText}>Bạn có 17 công việc bị quá hạn. Hãy kiểm tra và lên kế hoạch hoàn thành công việc.</Text>
          <Text style={styles.notificationDate}>20/08/2020, 06:00</Text>
        </View>
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 23,
    backgroundColor: '#fff',
    padding: 16,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    marginTop:20
  },
  notification: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 1,
    marginBottom: 0,
    borderWidth: 1,
    borderColor: '#fff',
  },
  notificationHighlight: {
    backgroundColor: '#f8f8f8',
    borderColor: '#fff',
  },
  notificationImage: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  notificationText: {
    fontSize: 14,
    color: '#666',
    marginVertical: 4,
  },
  notificationDate: {
    fontSize: 12,
    color: '#999',
  },
});